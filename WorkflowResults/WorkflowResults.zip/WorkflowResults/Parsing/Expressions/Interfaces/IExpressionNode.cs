namespace WorkflowResults.Parsing.Expressions.Interfaces;

public interface IExpressionNode
{
    public object Resolve();
}