namespace WorkflowResults.Parsing.Expressions.Interfaces;

public interface IBinaryExpressionNode : IExpressionNode;