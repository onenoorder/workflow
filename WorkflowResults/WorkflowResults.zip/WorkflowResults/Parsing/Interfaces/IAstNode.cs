namespace WorkflowResults.Parsing.Interfaces;

public interface IAstNode;