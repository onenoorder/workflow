namespace WorkflowResults.Helpers.Clients;

public record Client(string Name);