namespace WorkflowsTraining.Helpers.Clients;

public record Client(string Name);