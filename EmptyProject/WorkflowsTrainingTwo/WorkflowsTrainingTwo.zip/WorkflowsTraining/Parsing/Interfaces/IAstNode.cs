namespace WorkflowsTraining.Parsing.Interfaces;

public interface IAstNode;