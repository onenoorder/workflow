namespace WorkflowsTraining.Parsing.Expressions.Interfaces;

public interface IBinaryExpressionNode : IExpressionNode;