namespace WorkflowsTraining.Parsing.Expressions.Interfaces;

public interface IExpressionNode
{
    public object Resolve();
}